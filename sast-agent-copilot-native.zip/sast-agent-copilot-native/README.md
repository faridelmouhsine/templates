# Copilot-native SAST Qualification Agent (AXA)

## Prerequisites
Windows PowerShell 5.1, Git, VS Code Copilot Agent terminal, approved CXone GET access and ADO Code(Read). No Python, .ps1, package install, admin rights, or execution policy changes.

## Installation
1. Extract this archive to a local folder, then upload its files to an approved Git repository, or clone that repo on AXA laptop.
2. Open repository root in VS Code (`code .` if available).
3. In Copilot Agent, request: `Read .github/copilot-instructions.md and .github/skills/sast-qualification/SKILL.md. Execute bootstrap-sast-agent without executing scripts.`
4. Copilot may create config.json by copying config.example.json, and repository-mapping.json from its example, in the agent root only. Edit AXA host/organization. Both local config files are gitignored.
5. Provide secrets only through approved enterprise secret mechanisms or session environment; do not paste secrets into chat.
6. Validate CXone tenant auth/analyst field/project mapping before running. Never guess endpoints.
7. Request `run-sast-qualification`; for interruption request `resume-sast-qualification`.

## Important limits
No .ps1 files. Copilot runs approved individual interactive PowerShell commands. It is not an OS sandbox: enforce ADO Code(Read), CXone read-only access, and review terminal actions. Clone worktrees are immutable by policy; OS ACL/read-only mounts are needed for a hard filesystem guarantee.

## Sample bootstrap interactive commands
```powershell
$PSVersionTable.PSVersion
Get-ExecutionPolicy
git --version
Get-Command Invoke-RestMethod
Copy-Item .\config.example.json .\config.json
Copy-Item .\repository-mapping.example.json .\repository-mapping.json
New-Item -ItemType Directory -Force -Path .\workspace,.\state,.\reports,.\logs | Out-Null
```
Copy only if the destination does not already exist. These operations are confined to agent files.
