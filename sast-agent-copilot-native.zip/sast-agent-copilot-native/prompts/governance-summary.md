# Gouvernance SAST (français)
Report apps/projects/repos, languages/frameworks, initial Critical/High backlog, analyzed/remaining, classification distribution, CWE, layers, multi-repo findings, recurring TP/FP patterns, blockers and actions. FP rate = NOT_EXPLOITABLE / (CONFIRMED + NOT_EXPLOITABLE), clearly state denominator and exclusions. End with reusable Daily paragraph.
