---
description: Resume the last interrupted read-only SAST qualification run.
---
Use `sast-qualification` skill. Load state/current-run.json, revalidate latest scan IDs, repo HEADs and porcelain statuses, resume first pending finding, checkpoint and update French reports. Do not run scripts, alter application code or remote systems. Stop on drift.
