---
description: Validate and bootstrap the no-script, no-install Copilot SAST agent.
---
Use `sast-qualification` skill. Verify local tools using interactive PowerShell commands only. Check config, permitted CXone documentation/auth, analyst field and project-repository mapping, and ADO read-only credentials. Create only approved agent config/state files. Never execute or generate runnable .ps1, bypass Restricted policy, edit application code or invoke remote write APIs. If mappings are unknown, report exactly what is missing and ask for redacted examples. Produce French validation report.
