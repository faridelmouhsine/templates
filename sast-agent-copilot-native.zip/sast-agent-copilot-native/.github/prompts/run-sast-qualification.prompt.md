---
description: Execute read-only SAST qualification for two CXone applications.
---
Use `sast-qualification` skill. Read global safety instructions. Perform discovery, show candidates, select 2, clone relevant repos read-only, map cross-project architecture, compare scan baseline, qualify findings with evidence, checkpoint every finding and produce French reports. Do not run scripts, mutate application files, commit, push, create PRs or update CXone. Stop on any unsafe operation or missing mapping.
