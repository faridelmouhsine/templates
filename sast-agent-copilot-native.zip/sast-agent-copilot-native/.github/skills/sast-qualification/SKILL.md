---
name: sast-qualification
description: Qualify Checkmarx One High/Critical To Verify SAST findings assigned to Farid using immutable Azure DevOps source repositories, cross-project evidence, resumable JSON state and French reporting, without executing scripts.
---

# Operational contract
Read `.github/copilot-instructions.md` and `references/terminal-command-policy.md` before any terminal command.

## Phases
1. BOOTSTRAP: confirm PowerShell 5.1, Git, terminal approvals, config.json, approved CXone auth flow and ADO Code(Read). Never execute .ps1. If tenant details unknown, stop and request permitted documentation/sample (redacted).
2. DISCOVER: via validated CXone read-only GET calls list applications assigned to analyst, related projects, latest SAST scans, Critical/High To Verify findings. Preserve raw IDs, scan SHA, dates, severity, CWE, source/sink and links. Do not infer missing metadata.
3. PRIORITIZE: present candidate list; choose exactly 2 apps ranked Critical count, High count, then oldest unresolved, unless user explicitly changes.
4. ACQUIRE: create `workspace/<safe-app-name>/`; clone related repos within it using approved read-only Git authentication. Before any clone verify destination does not exist and URL belongs to approved ADO org. Never use clone flags that run external hooks or custom helpers. No submodules unless separately authorized. Do not run `git pull`.
5. MAP: create app-level application-context.json (outside cloned repos); identify actual front/BFF/API/backend/microservice/shared roles, languages/frameworks, endpoints, calls, auth, persistence and inter-repo links. Cite source paths.
6. BASELINE: store per repo HEAD, branch, porcelain status, scan commit if provided. Compare scan commit vs current HEAD using git diff/show. Relevant changed code => CODE_CHANGED_SINCE_SCAN, not NOT_EXPLOITABLE. If scan SHA unavailable => record limitation and prefer manual review where material.
7. QUALIFY: trace attacker input through trust boundaries and all relevant repositories to sink; inspect validation, sanitization, parameterization, encoding, authorization, persistence, alternate APIs and bypass paths. Conclusions: CONFIRMED / NOT_EXPLOITABLE / NEEDS_MANUAL_REVIEW / CODE_CHANGED_SINCE_SCAN. Positive proof required for NOT_EXPLOITABLE. Evidence repo:path:line and reasoning. No source writes.
8. CHECKPOINT: update state/current-run.json after every finding, including scan ID, HEADs, completed IDs, pending IDs, phase, evidence and timestamps. Atomic update via a new temporary state file in state/ and rename only after validation. Never store secrets.
9. REPORT: create reports/YYYY-MM-DD/qualification.md, findings.json, gouvernance.md, French daily summary; include counts, CWE, layers, multi-repo correlations, remaining backlog, denominator-aware false positive rate. No CXone writes.
10. RESUME: reload state, verify scans/HEADs/integrity and resume first pending finding. If changed, mark BLOCKED and request human decision.

## Stop conditions
Restricted execution policy blocks a requested script; missing approved auth; unclear analyst mapping; unsupported endpoint; unexpected source-tree change; insufficient evidence; scan baseline drift; command outside allowlist.
