# Terminal command policy (PowerShell 5.1 interactive)

Allowed after checking exact arguments and paths:
- `$PSVersionTable.PSVersion`, `Get-ExecutionPolicy`, `git --version`, `Get-Command Invoke-RestMethod`
- `Get-Content`, `ConvertFrom-Json`, `ConvertTo-Json`, `Select-Object`, `Where-Object`, `Group-Object`, `Measure-Object`, `Get-ChildItem`, `Test-Path`, `Resolve-Path`
- `New-Item`, `Set-Content`, `Move-Item` ONLY for state/, reports/, logs/, app-level application-context.json or explicitly approved bootstrap config files; never inside cloned repositories
- `Invoke-RestMethod -Method Get` ONLY to validated CXone/ADO HTTPS endpoints, with approved read-only auth
- Git clone/fetch/status/log/show/diff/grep/rev-parse/ls-files/branch --show-current only. `fetch` changes `.git` refs, not application files; record resulting refs/HEAD.

Never run `.ps1`, dot-source scripts, `powershell -File`, `-Command` generated wrappers, `-EncodedCommand`, `-ExecutionPolicy`, `Invoke-Expression`, `iex`, `curl | iex`, scriptblock loaders, installers, compilation, code formatters or tests that write files.

PowerShell syntax examples (type or paste interactively; NOT saved/executed as .ps1):
`$cfg = Get-Content .\config.json -Raw | ConvertFrom-Json`
`git -C .\workspace\APP\repo rev-parse HEAD`
`git -C .\workspace\APP\repo status --porcelain=v1 --untracked-files=all`
`git -C .\workspace\APP\repo grep -n -I -e 'pattern'`

For Azure DevOps PAT (only if approved), never print PAT or Authorization header. Example read-only GET:
`$token = [Environment]::GetEnvironmentVariable('AZURE_DEVOPS_PAT','Process')`
`$b64 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(':' + $token))`
`$headers = @{ Authorization = 'Basic ' + $b64; Accept = 'application/json' }`
`$repositories = Invoke-RestMethod -Method Get -Uri 'https://dev.azure.com/ORG/PROJECT/_apis/git/repositories?api-version=7.1' -Headers $headers`
`$headers = $null; $b64 = $null; $token = $null`

CXone auth flow MUST be verified from tenant documentation; do not assume raw API key is Bearer. Never print token.

Integrity note: clean status before/after is a detection measure, not a guarantee against malicious or accidental writes. True enforcement requires OS permissions/sandbox or approved read-only mount.
